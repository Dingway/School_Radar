<?php

	define('DB_NAME', 'school_db');
	define('DB_USER', 'school');
	define('DB_PASSWORD', 'ViaMedia321');
	define('DB_HOST', 'localhost');


?>